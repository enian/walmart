import os, glob
import csv
for file in glob.glob("*.csv"):
    print(file)

    fname=file
    fhand = open(fname)

    for line in fhand:
        line = line.strip()
        line = line.split(',')
        # line=line.replace("'", "")

        # print(line)

        storeno = line[0]
        storeno = storeno.split("\'")
        storeno = storeno[1]

        date = line[1]
        date = date.replace("'", "")

        pid = line[2]
        pid = pid.replace("'", "")

        units = (line[3])

        units = units.replace("'", "")
        units = units.replace("]\"", "")
        units = int(units)

        product_state = None

        if units >= 60:
            product_state = "High"
        elif units >= 30:
            product_state = "Medium"
        else:
            product_state = "Low"

        # print(product_state)
        # print(date, storeno, pid, units, product_state)


        with open(" " +fname, "a", newline='') as scoreFile:
            scoreFileWriter = csv.writer(scoreFile)
            scoreFileWriter.writerow([date,storeno,pid,units,product_state])
        scoreFile.close()