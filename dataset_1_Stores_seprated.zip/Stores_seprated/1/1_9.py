# takes the file splits it into store no date pid and units and adds it into the database......
import sqlite3

conn= sqlite3.connect('wm.sqlite')
cur = conn.cursor()

count=0

cur.execute(''' DROP TABLE IF EXISTS A_1_99 ''')

cur.execute(''' CREATE TABLE A_1_99 (storeno INTEGER,date DATE,pid INTEGER,units INTEGER )''')

fhand= open("1_99.csv")
for line in fhand:
    line=line.strip()
    line=line.split(',')
    storeno=line[0]
    date=line[1]
    pid=line[2]
    units=line[3]
    print(storeno,date,pid,units)
    count = count+1
    cur.execute('''INSERT INTO A_1_99(storeno,date,pid,units)
        values(?,?,?,?)''', (storeno,date,pid,units))
conn.commit()


cur.close()
print(count)

